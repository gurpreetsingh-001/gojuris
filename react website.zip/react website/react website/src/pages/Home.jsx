// src/pages/Home.jsx
import React from 'react';
import Hero from '../components/Hero';
import SearchInterface from '../components/SearchInterface';
import Features from '../components/Features';
import NewSection from '../components/NewSection'; // Add this import
import VideoSection from '../components/VideoSection';
import Services from '../components/Services';
import CallToAction from '../components/CallToAction';
import Team from '../components/Team';
import Testimonials from '../components/Testimonials';
import Blog from '../components/Blog';
import ContactMap from '../components/ContactMap';
import Contact from '../components/Contact';
import NewsJudgement from '../components/NewsJudgement';

const Home = () => {
  return (
    <>
      <Hero />
      <SearchInterface />
      <Features />
      <NewSection /> {/* New component placed above VideoSection */}
      <VideoSection />
      <Services />
      <CallToAction />
      <NewsJudgement/>
      <Blog />
      {/*<Team />*/}
      <Testimonials />
      <ContactMap />
      {/* <Contact /> */}
    </>
  );
};

export default Home;